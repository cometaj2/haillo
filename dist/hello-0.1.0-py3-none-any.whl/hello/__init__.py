import sys
from . import config

sys.path.insert(0, config.root)
