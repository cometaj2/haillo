from __future__ import absolute_import, division, print_function

__version__ = "0.1.0"
dependencies = ["flask==3.0.1",
                "huckle==5.5.4",
                "hcli_hai>=2.1.3"]
